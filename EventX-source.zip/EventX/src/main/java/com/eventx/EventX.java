package com.eventx;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class EventX extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private ArenaStore arenas;
    private StatsManager stats;
    private KitManager kits;
    private EventManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        arenas = new ArenaStore(this);
        stats = new StatsManager(this);
        kits = new KitManager(this);
        manager = new EventManager(this);

        EventCommand cmd = new EventCommand(this);
        PluginCommand pc = getCommand("event");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        getServer().getPluginManager().registerEvents(new EventListener(this), this);
        getLogger().info("EventX aktif! Gamemode: LMS, Spleef, TNT Run, Sumo, Snowball");
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.shutdown();
        if (stats != null) stats.save();
    }

    public void reload() {
        reloadConfig();
        arenas.load();
    }

    public ArenaStore arenas() { return arenas; }
    public StatsManager stats() { return stats; }
    public KitManager kits() { return kits; }
    public EventManager manager() { return manager; }

    private String fill(String s, String[] kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return s;
    }

    /** Pesan dengan prefix. */
    public Component msg(String key, String... kv) {
        String raw = getConfig().getString("messages." + key, "<red>[" + key + "]");
        return MM.deserialize(getConfig().getString("prefix", "") + fill(raw, kv));
    }

    /** Pesan tanpa prefix. */
    public Component raw(String key, String... kv) {
        String raw = getConfig().getString("messages." + key, key);
        return MM.deserialize(fill(raw, kv));
    }

    public Component mm(String s) {
        return MM.deserialize(s);
    }
}
