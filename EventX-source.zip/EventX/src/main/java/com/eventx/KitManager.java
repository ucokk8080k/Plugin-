package com.eventx;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class KitManager {

    private final EventX plugin;

    public KitManager(EventX plugin) {
        this.plugin = plugin;
    }

    private ConfigurationSection section(String name) {
        return plugin.getConfig().getConfigurationSection("kits." + name.toLowerCase());
    }

    public List<String> names() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("kits");
        if (s == null) return new ArrayList<>();
        Set<String> keys = s.getKeys(false);
        return new ArrayList<>(keys);
    }

    public boolean exists(String name) {
        return name != null && !name.isEmpty() && section(name) != null;
    }

    public String description(String name) {
        ConfigurationSection s = section(name);
        return s == null ? "" : s.getString("description", "");
    }

    public String modeKit(GameType t) {
        String k = plugin.getConfig().getString("mode-kits." + t.name(), "");
        return (k == null || k.isEmpty()) ? null : k.toLowerCase();
    }

    public boolean canUse(Player p, String name) {
        ConfigurationSection s = section(name);
        if (s == null) return false;
        String perm = s.getString("permission", "");
        return perm == null || perm.isEmpty() || p.hasPermission(perm);
    }

    private ItemStack parseItem(String line) {
        String[] parts = line.split(":");
        Material m = Material.matchMaterial(parts[0].trim());
        if (m == null || m.isAir()) return null;
        int amount = 1;
        if (parts.length > 1) {
            try {
                amount = Integer.parseInt(parts[1].trim());
            } catch (NumberFormatException ignored) {
            }
        }
        ItemStack it = new ItemStack(m, Math.max(1, amount));
        if (parts.length > 2) {
            for (String e : parts[2].split(",")) {
                String[] kv = e.split("=");
                Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(kv[0].trim().toLowerCase()));
                if (en == null) continue;
                int lvl = 1;
                if (kv.length > 1) {
                    try {
                        lvl = Integer.parseInt(kv[1].trim());
                    } catch (NumberFormatException ignored) {
                    }
                }
                it.addUnsafeEnchantment(en, lvl);
            }
        }
        return it;
    }

    public void give(Player p, String name) {
        ConfigurationSection sec = section(name);
        if (sec == null) return;
        boolean unbreakable = plugin.getConfig().getBoolean("game.kit-unbreakable", true);
        PlayerInventory inv = p.getInventory();

        for (String line : sec.getStringList("items")) {
            ItemStack it = parseItem(line);
            if (it == null) {
                plugin.getLogger().warning("Item kit tidak valid: " + line);
                continue;
            }
            if (unbreakable && it.getType().getMaxDurability() > 0) {
                ItemMeta meta = it.getItemMeta();
                if (meta != null) {
                    meta.setUnbreakable(true);
                    it.setItemMeta(meta);
                }
            }
            String n = it.getType().name();
            if (n.endsWith("_HELMET")) inv.setHelmet(it);
            else if (n.endsWith("_CHESTPLATE") || n.equals("ELYTRA")) inv.setChestplate(it);
            else if (n.endsWith("_LEGGINGS")) inv.setLeggings(it);
            else if (n.endsWith("_BOOTS")) inv.setBoots(it);
            else if (n.equals("SHIELD")) inv.setItemInOffHand(it);
            else inv.addItem(it);
        }

        for (String line : sec.getStringList("effects")) {
            String[] parts = line.split(":");
            PotionEffectType type = Registry.EFFECT.get(NamespacedKey.minecraft(parts[0].trim().toLowerCase()));
            if (type == null) continue;
            int amp = 0;
            if (parts.length > 1) {
                try {
                    amp = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException ignored) {
                }
            }
            p.addPotionEffect(new PotionEffect(type, PotionEffect.INFINITE_DURATION, amp, false, false));
        }
    }
}
