package com.eventx;

public enum GameType {
    LMS("Last Man Standing", true),
    SPLEEF("Spleef", false),
    TNTRUN("TNT Run", false),
    SUMO("Sumo", false),
    SNOWBALL("Snowball Fight", false);

    private final String display;
    private final boolean kitSelectable;

    GameType(String display, boolean kitSelectable) {
        this.display = display;
        this.kitSelectable = kitSelectable;
    }

    public String getDisplay() { return display; }
    public boolean isKitSelectable() { return kitSelectable; }

    public static GameType fromString(String s) {
        if (s == null) return null;
        String n = s.toUpperCase().replaceAll("[^A-Z]", "");
        for (GameType t : values()) {
            if (t.name().equals(n)) return t;
        }
        return null;
    }
}
