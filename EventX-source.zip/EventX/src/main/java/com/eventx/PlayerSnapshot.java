package com.eventx;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Menyimpan kondisi pemain sebelum join event, lalu mengembalikannya. */
public class PlayerSnapshot {

    private ItemStack[] contents = new ItemStack[41];
    private Location location;
    private GameMode gameMode = GameMode.SURVIVAL;
    private double health = 20.0;
    private int food = 20;
    private float saturation = 5f;
    private int level;
    private float exp;
    private List<PotionEffect> effects = new ArrayList<>();
    private boolean allowFlight;

    public static double maxHealth(Player p) {
        AttributeInstance a = p.getAttribute(Attribute.MAX_HEALTH);
        return a != null ? a.getValue() : 20.0;
    }

    public static PlayerSnapshot capture(Player p) {
        PlayerSnapshot s = new PlayerSnapshot();
        s.contents = p.getInventory().getContents().clone();
        s.location = p.getLocation();
        s.gameMode = p.getGameMode();
        s.health = p.getHealth();
        s.food = p.getFoodLevel();
        s.saturation = p.getSaturation();
        s.level = p.getLevel();
        s.exp = p.getExp();
        s.effects = new ArrayList<>(p.getActivePotionEffects());
        s.allowFlight = p.getAllowFlight();
        return s;
    }

    public void restore(Player p) {
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) {
            p.removePotionEffect(e.getType());
        }
        p.getInventory().setContents(contents);
        p.setGameMode(gameMode);
        p.setAllowFlight(allowFlight);
        p.setLevel(level);
        p.setExp(exp);
        p.setFoodLevel(food);
        p.setSaturation(saturation);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setVelocity(new Vector(0, 0, 0));
        p.setHealth(Math.max(1.0, Math.min(health, maxHealth(p))));
        if (location != null && location.getWorld() != null) p.teleport(location);
        for (PotionEffect e : effects) p.addPotionEffect(e);
        p.updateInventory();
    }

    public void save(File f) {
        File parent = f.getParentFile();
        if (parent != null) parent.mkdirs();
        YamlConfiguration c = new YamlConfiguration();
        c.set("contents", Arrays.asList(contents));
        c.set("location", location);
        c.set("gamemode", gameMode.name());
        c.set("health", health);
        c.set("food", food);
        c.set("saturation", (double) saturation);
        c.set("level", level);
        c.set("exp", (double) exp);
        c.set("effects", effects);
        c.set("allowflight", allowFlight);
        try {
            c.save(f);
        } catch (IOException ignored) {
        }
    }

    public static PlayerSnapshot load(File f) {
        if (!f.exists()) return null;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(f);
        PlayerSnapshot s = new PlayerSnapshot();
        List<?> list = c.getList("contents", new ArrayList<>());
        ItemStack[] arr = new ItemStack[Math.max(list.size(), 41)];
        for (int i = 0; i < list.size(); i++) {
            Object o = list.get(i);
            arr[i] = o instanceof ItemStack is ? is : null;
        }
        s.contents = arr;
        s.location = c.getLocation("location");
        try {
            s.gameMode = GameMode.valueOf(c.getString("gamemode", "SURVIVAL"));
        } catch (IllegalArgumentException ex) {
            s.gameMode = GameMode.SURVIVAL;
        }
        s.health = c.getDouble("health", 20.0);
        s.food = c.getInt("food", 20);
        s.saturation = (float) c.getDouble("saturation", 5.0);
        s.level = c.getInt("level", 0);
        s.exp = (float) c.getDouble("exp", 0.0);
        s.allowFlight = c.getBoolean("allowflight", false);
        for (Object o : c.getList("effects", new ArrayList<>())) {
            if (o instanceof PotionEffect pe) s.effects.add(pe);
        }
        return s;
    }
}
