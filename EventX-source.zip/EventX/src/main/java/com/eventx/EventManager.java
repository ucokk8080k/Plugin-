package com.eventx;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

public class EventManager {

    public enum State { IDLE, WAITING, COUNTDOWN, RUNNING, ENDING }

    private final EventX plugin;

    private State state = State.IDLE;
    private GameType type;

    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Set<UUID> spectators = new HashSet<>();
    private final Map<UUID, PlayerSnapshot> snapshots = new HashMap<>();
    private final Map<UUID, String> chosenKit = new HashMap<>();
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<Block, BlockData> changedBlocks = new LinkedHashMap<>();
    private final Set<Block> pendingRemoval = new HashSet<>();

    private Set<UUID> pendingWinners = new HashSet<>();
    private Set<UUID> pendingParticipants = new HashSet<>();

    private boolean pvp;
    private boolean forced;
    private boolean soloTest;
    private double deathY;
    private int countdown;
    private int countdownTotal = 1;
    private int elapsedTicks;
    private BossBar bar;
    private BukkitTask countdownTask;
    private BukkitTask gameTask;
    private BukkitTask graceTask;
    private BukkitTask endTask;

    public EventManager(EventX plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------ getters

    public State getState() { return state; }
    public GameType getType() { return type; }
    public boolean isPvp() { return pvp; }
    public int participantCount() { return participants.size(); }
    public int aliveCount() { return alive.size(); }

    public boolean isInEvent(Player p) {
        UUID id = p.getUniqueId();
        return participants.contains(id) || spectators.contains(id);
    }

    public boolean isAlive(Player p) { return alive.contains(p.getUniqueId()); }

    public List<String> participantNames() {
        List<String> out = new ArrayList<>();
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            out.add((alive.contains(id) ? "" : "(out) ") + p.getName());
        }
        return out;
    }

    public Location respawnLocation() {
        return type != null ? plugin.arenas().getSpectator(type) : plugin.arenas().getLobby();
    }

    public Set<Material> spleefBlocks() {
        Set<Material> set = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("spleef.blocks")) {
            Material m = Material.matchMaterial(s);
            if (m != null) set.add(m);
        }
        return set;
    }

    public File snapshotFile(UUID id) {
        return new File(plugin.getDataFolder(), "snapshots/" + id + ".yml");
    }

    // ------------------------------------------------------------ helpers

    private void forEachOnline(Consumer<Player> action) {
        Set<UUID> all = new HashSet<>(participants);
        all.addAll(spectators);
        for (UUID id : all) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) action.accept(p);
        }
    }

    private void broadcastEvent(Component c) {
        forEachOnline(p -> p.sendMessage(c));
    }

    private void restore(Player p) {
        UUID id = p.getUniqueId();
        PlayerSnapshot snap = snapshots.remove(id);
        if (snap != null) {
            snap.restore(p);
            snapshotFile(id).delete();
        }
    }

    private void resetPlayer(Player p, GameMode gm) {
        p.getInventory().clear();
        for (var e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        p.setGameMode(gm);
        p.setHealth(PlayerSnapshot.maxHealth(p));
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setLevel(0);
        p.setExp(0f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }

    private Title.Times times() {
        return Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1100), Duration.ofMillis(300));
    }

    private void sound(Player p, Sound s, float pitch) {
        p.playSound(p.getLocation(), s, 1f, pitch);
    }

    private String fmt(int sec) {
        if (sec < 0) sec = 0;
        return String.format("%d:%02d", sec / 60, sec % 60);
    }

    private float clamp(float f) {
        return Math.max(0f, Math.min(1f, f));
    }

    private int minPlayers() { return plugin.getConfig().getInt("game.min-players", 2); }

    private void refreshBar() {
        if (bar == null || type == null) return;
        String mode = type.getDisplay();
        switch (state) {
            case WAITING -> {
                bar.name(plugin.raw("bar-waiting", "mode", mode,
                        "count", String.valueOf(participants.size()), "min", String.valueOf(minPlayers())));
                bar.progress(clamp(participants.size() / (float) Math.max(1, minPlayers())));
                bar.color(BossBar.Color.YELLOW);
            }
            case COUNTDOWN -> {
                bar.name(plugin.raw("bar-countdown", "mode", mode, "time", String.valueOf(countdown)));
                bar.progress(clamp(countdown / (float) countdownTotal));
                bar.color(BossBar.Color.GREEN);
            }
            case RUNNING -> {
                int max = plugin.getConfig().getInt("game.max-seconds", 600);
                int left = max > 0 ? max - elapsedTicks / 20 : 0;
                bar.name(plugin.raw("bar-running", "mode", mode,
                        "alive", String.valueOf(alive.size()), "time", max > 0 ? fmt(left) : "-"));
                bar.progress(max > 0 ? clamp(left / (float) max) : 1f);
                bar.color(BossBar.Color.RED);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------ lifecycle

    /** @return key pesan error, atau null kalau berhasil. */
    public String create(GameType t) {
        if (state != State.IDLE) return "event-already-running";
        if (!plugin.arenas().isReady(t)) return "arena-not-ready";
        type = t;
        state = State.WAITING;
        forced = false;
        soloTest = false;
        elapsedTicks = 0;
        bar = BossBar.bossBar(Component.text("Event"), 0f, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
        Bukkit.broadcast(plugin.msg("announce", "mode", t.getDisplay(),
                "min", String.valueOf(minPlayers()),
                "max", String.valueOf(plugin.getConfig().getInt("game.max-players", 50))));
        return null;
    }

    public String join(Player p) {
        if (state == State.IDLE) return "no-event";
        if (state != State.WAITING && state != State.COUNTDOWN) return "already-started";
        if (isInEvent(p)) return "already-joined";
        int max = plugin.getConfig().getInt("game.max-players", 50);
        if (participants.size() >= max) return "event-full";

        UUID id = p.getUniqueId();
        if (p.isInsideVehicle()) p.leaveVehicle();
        PlayerSnapshot snap = PlayerSnapshot.capture(p);
        snapshots.put(id, snap);
        snap.save(snapshotFile(id));

        participants.add(id);
        alive.add(id);
        resetPlayer(p, GameMode.ADVENTURE);
        p.teleport(plugin.arenas().getLobby());
        p.showBossBar(bar);

        broadcastEvent(plugin.msg("player-joined", "player", p.getName(),
                "count", String.valueOf(participants.size()), "max", String.valueOf(max)));
        refreshBar();
        checkAutoStart();
        return null;
    }

    public String spectate(Player p) {
        if (state == State.IDLE) return "no-event";
        if (isInEvent(p)) return "already-joined";
        UUID id = p.getUniqueId();
        if (p.isInsideVehicle()) p.leaveVehicle();
        PlayerSnapshot snap = PlayerSnapshot.capture(p);
        snapshots.put(id, snap);
        snap.save(snapshotFile(id));
        spectators.add(id);
        p.getInventory().clear();
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(plugin.arenas().getSpectator(type));
        p.showBossBar(bar);
        return null;
    }

    public void leave(Player p, boolean quitting) {
        UUID id = p.getUniqueId();
        boolean wasParticipant = participants.contains(id);
        boolean wasSpectator = spectators.contains(id);
        if (!wasParticipant && !wasSpectator) return;

        boolean wasAlive = alive.remove(id);
        participants.remove(id);
        spectators.remove(id);
        lives.remove(id);
        chosenKit.remove(id);
        if (bar != null) p.hideBossBar(bar);
        restore(p);

        if (!quitting) p.sendMessage(plugin.msg("left"));

        if (wasAlive) {
            if (state == State.WAITING || state == State.COUNTDOWN) {
                broadcastEvent(plugin.msg("player-left", "player", p.getName(),
                        "count", String.valueOf(participants.size())));
                refreshBar();
            } else if (state == State.RUNNING) {
                broadcastEvent(plugin.msg("player-quit", "player", p.getName()));
                checkWin();
            }
        }
    }

    public void kick(Player target) {
        if (!isInEvent(target)) return;
        target.sendMessage(plugin.msg("kicked"));
        leave(target, true);
    }

    /** @return key pesan error, atau null kalau berhasil. */
    public String setKit(Player p, String kit) {
        if (!participants.contains(p.getUniqueId())) return "not-in-event";
        if (!type.isKitSelectable()) return "kit-fixed";
        if (!plugin.kits().exists(kit)) return "kit-not-found";
        if (!plugin.kits().canUse(p, kit)) return "kit-no-permission";
        chosenKit.put(p.getUniqueId(), kit.toLowerCase());
        return null;
    }

    private void checkAutoStart() {
        if (state == State.WAITING && participants.size() >= minPlayers()) {
            startCountdown(plugin.getConfig().getInt("game.countdown-seconds", 30));
        }
    }

    private void startCountdown(int seconds) {
        if (state != State.WAITING) return;
        state = State.COUNTDOWN;
        countdown = seconds;
        countdownTotal = Math.max(1, seconds);
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, this::countdownTick, 0L, 20L);
    }

    /** Paksa mulai (admin). @return false jika belum ada pemain. */
    public boolean forceStart() {
        if (participants.isEmpty()) return false;
        if (state == State.WAITING) {
            forced = true;
            startCountdown(5);
            return true;
        }
        if (state == State.COUNTDOWN) {
            forced = true;
            countdown = Math.min(countdown, 5);
            return true;
        }
        return false;
    }

    private void cancelCountdown() {
        if (countdownTask != null) countdownTask.cancel();
        countdownTask = null;
        forced = false;
        state = State.WAITING;
        broadcastEvent(plugin.msg("countdown-cancelled"));
        refreshBar();
    }

    private void countdownTick() {
        if (state != State.COUNTDOWN) return;
        if (!forced && participants.size() < minPlayers()) {
            cancelCountdown();
            return;
        }
        refreshBar();
        if (countdown <= 0) {
            countdownTask.cancel();
            countdownTask = null;
            startGame();
            return;
        }
        if (countdown <= 5 || countdown % 10 == 0) {
            final int c = countdown;
            forEachOnline(p -> {
                if (c <= 5) {
                    p.showTitle(Title.title(plugin.raw("title-countdown", "seconds", String.valueOf(c)),
                            Component.empty(), times()));
                }
                sound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 1f);
            });
        }
        countdown--;
    }

    private void startGame() {
        state = State.RUNNING;
        pvp = false;
        elapsedTicks = 0;
        soloTest = forced && alive.size() < 2;

        alive.removeIf(id -> Bukkit.getPlayer(id) == null);
        List<Location> spawns = plugin.arenas().getSpawns(type);
        Double dy = plugin.arenas().getDeathY(type);
        if (dy != null) {
            deathY = dy;
        } else {
            double min = Double.MAX_VALUE;
            for (Location l : spawns) min = Math.min(min, l.getY());
            deathY = min - 15;
        }

        int i = 0;
        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Location sp = spawns.get(i++ % spawns.size());
            resetPlayer(p, GameMode.SURVIVAL);
            p.teleport(sp);
            giveKit(p);
            if (type == GameType.SNOWBALL) {
                lives.put(id, plugin.getConfig().getInt("snowball.lives", 3));
            }
            plugin.stats().addPlayed(p);
            p.showTitle(Title.title(plugin.raw("title-start"),
                    plugin.raw("title-start-sub", "mode", type.getDisplay()), times()));
            sound(p, Sound.ENTITY_ENDER_DRAGON_GROWL, 1f);
        }

        broadcastEvent(plugin.msg("started", "mode", type.getDisplay()));
        refreshBar();

        int grace = plugin.getConfig().getInt("game.grace-seconds", 5);
        if (grace > 0) {
            graceTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (state == State.RUNNING) {
                    pvp = true;
                    broadcastEvent(plugin.msg("pvp-on"));
                }
            }, grace * 20L);
        } else {
            pvp = true;
        }
        gameTask = Bukkit.getScheduler().runTaskTimer(plugin, this::gameTick, 2L, 2L);
        checkWin();
    }

    private void giveKit(Player p) {
        String k = type.isKitSelectable() ? chosenKit.get(p.getUniqueId()) : null;
        if (k == null) k = plugin.kits().modeKit(type);
        if (k != null) plugin.kits().give(p, k);
    }

    private void gameTick() {
        if (state != State.RUNNING) return;
        elapsedTicks += 2;

        for (UUID id : new ArrayList<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (p.getLocation().getY() < deathY) {
                eliminate(p, "jatuh");
                if (state != State.RUNNING) return;
            }
        }

        if (type == GameType.TNTRUN) tntRunTick();
        if (type == GameType.SNOWBALL && elapsedTicks % 60 == 0) refillSnowballs();
        if (elapsedTicks % 20 == 0) refreshBar();

        int max = plugin.getConfig().getInt("game.max-seconds", 600);
        if (max > 0 && elapsedTicks >= max * 20) {
            broadcastEvent(plugin.msg("time-up"));
            List<Player> winners = new ArrayList<>();
            for (UUID id : alive) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) winners.add(p);
            }
            endGame(winners);
        }
    }

    private void tntRunTick() {
        Set<Material> floor = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("tntrun.floor-blocks")) {
            Material m = Material.matchMaterial(s);
            if (m != null) floor.add(m);
        }
        long delay = plugin.getConfig().getInt("tntrun.remove-delay-ticks", 10);
        double[][] offsets = {{0, 0}, {0.3, 0}, {-0.3, 0}, {0, 0.3}, {0, -0.3}};
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            Location l = p.getLocation();
            for (double[] o : offsets) {
                Block b = l.clone().add(o[0], -0.5, o[1]).getBlock();
                if (!floor.contains(b.getType()) || pendingRemoval.contains(b)) continue;
                pendingRemoval.add(b);
                changedBlocks.putIfAbsent(b, b.getBlockData());
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    pendingRemoval.remove(b);
                    if (state == State.RUNNING) b.setType(Material.AIR, false);
                }, delay);
            }
        }
    }

    private void refillSnowballs() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            int count = 0;
            for (ItemStack it : p.getInventory().getContents()) {
                if (it != null && it.getType() == Material.SNOWBALL) count += it.getAmount();
            }
            if (count < 16) p.getInventory().addItem(new ItemStack(Material.SNOWBALL, 16 - count));
        }
    }

    public void recordBlock(Block b) {
        changedBlocks.putIfAbsent(b, b.getBlockData());
    }

    public void snowballHit(Player victim, Player attacker) {
        if (!alive.contains(victim.getUniqueId()) || !alive.contains(attacker.getUniqueId())) return;
        int left = lives.merge(victim.getUniqueId(), -1, Integer::sum);
        sound(victim, Sound.ENTITY_PLAYER_HURT, 1f);
        sound(attacker, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f);
        if (left <= 0) {
            eliminate(victim, "terkena snowball dari " + attacker.getName());
        } else {
            victim.sendMessage(plugin.msg("snowball-hit", "attacker", attacker.getName(), "lives", String.valueOf(left)));
        }
    }

    public void eliminate(Player p, String reason) {
        UUID id = p.getUniqueId();
        if (state != State.RUNNING || !alive.remove(id)) return;
        lives.remove(id);
        p.getInventory().clear();
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(plugin.arenas().getSpectator(type));
        p.showTitle(Title.title(plugin.raw("title-eliminated"), Component.empty(), times()));
        broadcastEvent(plugin.msg("eliminated", "player", p.getName(), "reason", reason,
                "alive", String.valueOf(alive.size())));
        refreshBar();
        checkWin();
    }

    private void checkWin() {
        if (state != State.RUNNING) return;
        if (soloTest) {
            if (alive.isEmpty()) endGame(new ArrayList<>());
            return;
        }
        if (alive.size() <= 1) {
            List<Player> winners = new ArrayList<>();
            for (UUID id : alive) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) winners.add(p);
            }
            endGame(winners);
        }
    }

    private void endGame(List<Player> winners) {
        if (state == State.ENDING || state == State.IDLE) return;
        state = State.ENDING;
        pvp = false;
        if (gameTask != null) gameTask.cancel();
        if (graceTask != null) graceTask.cancel();
        gameTask = null;
        graceTask = null;

        pendingWinners = new HashSet<>();
        pendingParticipants = new HashSet<>(participants);

        if (winners.isEmpty()) {
            Bukkit.broadcast(plugin.msg("no-winner", "mode", type.getDisplay()));
        } else {
            StringBuilder names = new StringBuilder();
            for (Player w : winners) {
                if (names.length() > 0) names.append(", ");
                names.append(w.getName());
                pendingWinners.add(w.getUniqueId());
                plugin.stats().addWin(w);
                w.showTitle(Title.title(plugin.raw("title-winner"), Component.empty(), times()));
                sound(w, Sound.ENTITY_PLAYER_LEVELUP, 1f);
            }
            Bukkit.broadcast(plugin.msg("winner", "player", names.toString(), "mode", type.getDisplay()));
        }

        int delay = plugin.getConfig().getInt("game.end-delay-seconds", 8);
        endTask = Bukkit.getScheduler().runTaskLater(plugin, () -> cleanup(true), delay * 20L);
    }

    private void runRewards(String path, Player p) {
        for (String c : plugin.getConfig().getStringList(path + ".commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
        }
    }

    public void forceStop() {
        if (state == State.IDLE) return;
        Bukkit.broadcast(plugin.msg("stopped"));
        cleanup(false);
    }

    public void shutdown() {
        if (state != State.IDLE) cleanup(false);
    }

    private void cleanup(boolean rewards) {
        if (countdownTask != null) countdownTask.cancel();
        if (gameTask != null) gameTask.cancel();
        if (graceTask != null) graceTask.cancel();
        if (endTask != null) endTask.cancel();
        countdownTask = null;
        gameTask = null;
        graceTask = null;
        endTask = null;

        // kembalikan blok yang berubah
        for (Map.Entry<Block, BlockData> e : changedBlocks.entrySet()) {
            e.getKey().setBlockData(e.getValue(), false);
        }
        changedBlocks.clear();
        pendingRemoval.clear();

        Set<UUID> all = new HashSet<>(participants);
        all.addAll(spectators);
        for (UUID id : all) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (bar != null) p.hideBossBar(bar);
            restore(p);
        }

        // hadiah diberikan SETELAH inventory dikembalikan
        if (rewards) {
            for (UUID id : pendingParticipants) {
                Player p = Bukkit.getPlayer(id);
                if (p == null) continue;
                runRewards(pendingWinners.contains(id) ? "rewards.winner" : "rewards.participant", p);
            }
        }

        participants.clear();
        alive.clear();
        spectators.clear();
        chosenKit.clear();
        lives.clear();
        snapshots.clear();
        pendingWinners = new HashSet<>();
        pendingParticipants = new HashSet<>();
        state = State.IDLE;
        type = null;
        forced = false;
        soloTest = false;
        pvp = false;
        bar = null;
    }

    /** Dipanggil saat pemain login: kembalikan inventory jika server sempat crash di tengah event. */
    public void restorePending(Player p) {
        if (isInEvent(p)) return;
        File f = snapshotFile(p.getUniqueId());
        if (!f.exists()) return;
        PlayerSnapshot snap = PlayerSnapshot.load(f);
        if (snap != null) snap.restore(p);
        f.delete();
    }
}
