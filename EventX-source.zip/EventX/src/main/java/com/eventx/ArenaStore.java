package com.eventx;

import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ArenaStore {

    private final EventX plugin;
    private final File file;
    private YamlConfiguration cfg;

    public ArenaStore(EventX plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "arenas.yml");
        load();
    }

    public void load() {
        plugin.getDataFolder().mkdirs();
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal menyimpan arenas.yml: " + e.getMessage());
        }
    }

    private String p(GameType t, String key) {
        return "arenas." + t.name() + "." + key;
    }

    public Location getLobby() { return cfg.getLocation("lobby"); }

    public void setLobby(Location l) {
        cfg.set("lobby", l);
        save();
    }

    public List<Location> getSpawns(GameType t) {
        List<Location> out = new ArrayList<>();
        List<?> list = cfg.getList(p(t, "spawns"), new ArrayList<>());
        for (Object o : list) {
            if (o instanceof Location l) out.add(l);
        }
        return out;
    }

    public int addSpawn(GameType t, Location l) {
        List<Location> s = getSpawns(t);
        s.add(l);
        cfg.set(p(t, "spawns"), s);
        save();
        return s.size();
    }

    public void clearSpawns(GameType t) {
        cfg.set(p(t, "spawns"), null);
        save();
    }

    public Location getSpectator(GameType t) {
        Location l = cfg.getLocation(p(t, "spectator"));
        return l != null ? l : getLobby();
    }

    public boolean hasSpectator(GameType t) {
        return cfg.getLocation(p(t, "spectator")) != null;
    }

    public void setSpectator(GameType t, Location l) {
        cfg.set(p(t, "spectator"), l);
        save();
    }

    public Double getDeathY(GameType t) {
        String path = p(t, "death-y");
        return cfg.contains(path) ? cfg.getDouble(path) : null;
    }

    public void setDeathY(GameType t, double y) {
        cfg.set(p(t, "death-y"), y);
        save();
    }

    public boolean isReady(GameType t) {
        return getLobby() != null && !getSpawns(t).isEmpty();
    }
}
