package com.eventx;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EventCommand implements CommandExecutor, TabCompleter {

    private static final List<String> PLAYER_SUBS =
            List.of("help", "join", "leave", "spectate", "kit", "info", "list", "stats", "top", "modes");
    private static final List<String> ADMIN_SUBS =
            List.of("create", "start", "stop", "kick", "setlobby", "addspawn", "clearspawns",
                    "setspec", "setdeathy", "arena", "reload");

    private final EventX plugin;

    public EventCommand(EventX plugin) {
        this.plugin = plugin;
    }

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        s.sendMessage(plugin.msg("player-only"));
        return null;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("eventx.admin")) return true;
        s.sendMessage(plugin.msg("no-permission"));
        return false;
    }

    private GameType modeArg(CommandSender s, String[] a, String usage) {
        if (a.length < 2) {
            s.sendMessage(plugin.msg("usage", "usage", usage));
            return null;
        }
        GameType t = GameType.fromString(a[1]);
        if (t == null) s.sendMessage(plugin.msg("invalid-mode"));
        return t;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        EventManager mgr = plugin.manager();
        if (a.length == 0) {
            sendInfo(s);
            s.sendMessage(plugin.mm("<gray>Ketik <yellow>/event help <gray>untuk daftar command."));
            return true;
        }

        switch (a[0].toLowerCase()) {
            case "help" -> sendHelp(s);

            case "join" -> {
                Player p = player(s);
                if (p == null) return true;
                if (!p.hasPermission("eventx.join")) {
                    p.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                String err = mgr.join(p);
                if (err != null) p.sendMessage(plugin.msg(err));
                else p.sendMessage(plugin.msg("joined", "mode", mgr.getType().getDisplay()));
            }

            case "leave" -> {
                Player p = player(s);
                if (p == null) return true;
                if (!mgr.isInEvent(p)) p.sendMessage(plugin.msg("not-in-event"));
                else mgr.leave(p, false);
            }

            case "spectate", "spec" -> {
                Player p = player(s);
                if (p == null) return true;
                String err = mgr.spectate(p);
                if (err != null) p.sendMessage(plugin.msg(err));
                else p.sendMessage(plugin.msg("spectating"));
            }

            case "kit" -> {
                if (a.length == 1 || a[1].equalsIgnoreCase("list")) {
                    s.sendMessage(plugin.msg("kit-header"));
                    for (String k : plugin.kits().names()) {
                        s.sendMessage(plugin.raw("kit-line", "kit", k, "desc", plugin.kits().description(k)));
                    }
                    s.sendMessage(plugin.mm("<gray>Pilih dengan <yellow>/event kit <nama>"));
                    return true;
                }
                Player p = player(s);
                if (p == null) return true;
                if (mgr.getState() == EventManager.State.IDLE) {
                    p.sendMessage(plugin.msg("no-event"));
                    return true;
                }
                String err = mgr.setKit(p, a[1]);
                if (err != null) p.sendMessage(plugin.msg(err));
                else p.sendMessage(plugin.msg("kit-set", "kit", a[1].toLowerCase()));
            }

            case "info", "status" -> sendInfo(s);

            case "list", "players" -> {
                if (mgr.getState() == EventManager.State.IDLE) {
                    s.sendMessage(plugin.msg("no-event"));
                    return true;
                }
                s.sendMessage(plugin.msg("list-line", "players", String.join(", ", mgr.participantNames())));
            }

            case "stats" -> {
                Player target = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player pl ? pl : null);
                if (target == null) {
                    s.sendMessage(plugin.msg("player-not-found"));
                    return true;
                }
                s.sendMessage(plugin.msg("stats-line", "player", target.getName(),
                        "wins", String.valueOf(plugin.stats().getWins(target.getUniqueId())),
                        "played", String.valueOf(plugin.stats().getPlayed(target.getUniqueId()))));
            }

            case "top" -> {
                s.sendMessage(plugin.raw("top-header"));
                int rank = 1;
                for (Map.Entry<String, Integer> en : plugin.stats().top(10)) {
                    s.sendMessage(plugin.raw("top-line", "rank", String.valueOf(rank++),
                            "player", en.getKey(), "wins", String.valueOf(en.getValue())));
                }
            }

            case "modes" -> {
                s.sendMessage(plugin.raw("modes-header"));
                for (GameType t : GameType.values()) {
                    String desc = plugin.getConfig().getString("mode-desc." + t.name(), "");
                    s.sendMessage(plugin.raw("mode-line", "id", t.name().toLowerCase(),
                            "mode", t.getDisplay(), "desc", desc));
                }
            }

            // ---------------------------------------------------- admin
            case "create", "host" -> {
                if (!admin(s)) return true;
                GameType t = modeArg(s, a, "/event create <lms|spleef|tntrun|sumo|snowball>");
                if (t == null) return true;
                String err = mgr.create(t);
                if (err != null) s.sendMessage(plugin.msg(err));
            }

            case "start", "forcestart" -> {
                if (!admin(s)) return true;
                if (mgr.getState() == EventManager.State.IDLE) s.sendMessage(plugin.msg("no-event"));
                else if (!mgr.forceStart()) s.sendMessage(plugin.msg("cannot-start"));
            }

            case "stop", "end", "cancel" -> {
                if (!admin(s)) return true;
                if (mgr.getState() == EventManager.State.IDLE) s.sendMessage(plugin.msg("no-event"));
                else mgr.forceStop();
            }

            case "kick" -> {
                if (!admin(s)) return true;
                if (a.length < 2) {
                    s.sendMessage(plugin.msg("usage", "usage", "/event kick <player>"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(a[1]);
                if (target == null || !mgr.isInEvent(target)) s.sendMessage(plugin.msg("player-not-found"));
                else mgr.kick(target);
            }

            case "setlobby" -> {
                if (!admin(s)) return true;
                Player p = player(s);
                if (p == null) return true;
                plugin.arenas().setLobby(p.getLocation());
                p.sendMessage(plugin.msg("set-lobby"));
            }

            case "addspawn" -> {
                if (!admin(s)) return true;
                Player p = player(s);
                if (p == null) return true;
                GameType t = modeArg(s, a, "/event addspawn <mode>");
                if (t == null) return true;
                int n = plugin.arenas().addSpawn(t, p.getLocation());
                p.sendMessage(plugin.msg("spawn-added", "mode", t.getDisplay(), "count", String.valueOf(n)));
            }

            case "clearspawns" -> {
                if (!admin(s)) return true;
                GameType t = modeArg(s, a, "/event clearspawns <mode>");
                if (t == null) return true;
                plugin.arenas().clearSpawns(t);
                s.sendMessage(plugin.msg("spawns-cleared", "mode", t.getDisplay()));
            }

            case "setspec" -> {
                if (!admin(s)) return true;
                Player p = player(s);
                if (p == null) return true;
                GameType t = modeArg(s, a, "/event setspec <mode>");
                if (t == null) return true;
                plugin.arenas().setSpectator(t, p.getLocation());
                p.sendMessage(plugin.msg("spec-set", "mode", t.getDisplay()));
            }

            case "setdeathy" -> {
                if (!admin(s)) return true;
                Player p = player(s);
                if (p == null) return true;
                GameType t = modeArg(s, a, "/event setdeathy <mode>");
                if (t == null) return true;
                Location l = p.getLocation();
                plugin.arenas().setDeathY(t, l.getY());
                p.sendMessage(plugin.msg("deathy-set", "mode", t.getDisplay(),
                        "y", String.format("%.1f", l.getY())));
            }

            case "arena" -> {
                if (!admin(s)) return true;
                GameType t = modeArg(s, a, "/event arena <mode>");
                if (t == null) return true;
                ArenaStore ar = plugin.arenas();
                Double dy = ar.getDeathY(t);
                s.sendMessage(plugin.msg("arena-info", "mode", t.getDisplay(),
                        "lobby", ar.getLobby() != null ? "ya" : "BELUM",
                        "spawns", String.valueOf(ar.getSpawns(t).size()),
                        "spec", ar.hasSpectator(t) ? "ya" : "pakai lobby",
                        "deathy", dy != null ? String.format("%.1f", dy) : "otomatis"));
            }

            case "reload" -> {
                if (!admin(s)) return true;
                plugin.reload();
                s.sendMessage(plugin.msg("reloaded"));
            }

            default -> s.sendMessage(plugin.msg("unknown"));
        }
        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage(plugin.raw("help-header"));
        for (String line : plugin.getConfig().getStringList("messages.help-player")) {
            s.sendMessage(plugin.mm(line));
        }
        if (s.hasPermission("eventx.admin")) {
            s.sendMessage(plugin.raw("help-admin-header"));
            for (String line : plugin.getConfig().getStringList("messages.help-admin")) {
                s.sendMessage(plugin.mm(line));
            }
        }
    }

    private void sendInfo(CommandSender s) {
        EventManager mgr = plugin.manager();
        if (mgr.getState() == EventManager.State.IDLE) {
            s.sendMessage(plugin.msg("no-event"));
            return;
        }
        s.sendMessage(plugin.msg("info-line", "mode", mgr.getType().getDisplay(),
                "state", mgr.getState().name(),
                "players", String.valueOf(mgr.participantCount()),
                "alive", String.valueOf(mgr.aliveCount())));
        s.sendMessage(plugin.mm("<gray>Join: <yellow>/event join"));
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> out = new ArrayList<>();
        for (String x : list) {
            if (x.toLowerCase().startsWith(prefix.toLowerCase())) out.add(x);
        }
        return out;
    }

    private List<String> modeNames() {
        List<String> out = new ArrayList<>();
        for (GameType t : GameType.values()) out.add(t.name().toLowerCase());
        return out;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(PLAYER_SUBS);
            if (s.hasPermission("eventx.admin")) subs.addAll(ADMIN_SUBS);
            return filter(subs, a[0]);
        }
        if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "create", "host", "addspawn", "clearspawns", "setspec", "setdeathy", "arena" -> {
                    if (s.hasPermission("eventx.admin")) return filter(modeNames(), a[1]);
                }
                case "kit" -> {
                    List<String> k = new ArrayList<>(plugin.kits().names());
                    k.add("list");
                    return filter(k, a[1]);
                }
                case "kick", "stats" -> {
                    List<String> names = new ArrayList<>();
                    for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
                    return filter(names, a[1]);
                }
                default -> { }
            }
        }
        return List.of();
    }
}
