package com.eventx;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class StatsManager {

    private final EventX plugin;
    private final File file;
    private final YamlConfiguration cfg;

    public StatsManager(EventX plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal menyimpan stats.yml: " + e.getMessage());
        }
    }

    private String key(UUID id) { return "players." + id; }

    public void addPlayed(Player p) {
        String k = key(p.getUniqueId());
        cfg.set(k + ".name", p.getName());
        cfg.set(k + ".played", cfg.getInt(k + ".played", 0) + 1);
        save();
    }

    public void addWin(Player p) {
        String k = key(p.getUniqueId());
        cfg.set(k + ".name", p.getName());
        cfg.set(k + ".wins", cfg.getInt(k + ".wins", 0) + 1);
        save();
    }

    public int getWins(UUID id) { return cfg.getInt(key(id) + ".wins", 0); }
    public int getPlayed(UUID id) { return cfg.getInt(key(id) + ".played", 0); }

    public List<Map.Entry<String, Integer>> top(int n) {
        List<Map.Entry<String, Integer>> list = new ArrayList<>();
        ConfigurationSection sec = cfg.getConfigurationSection("players");
        if (sec == null) return list;
        for (String id : sec.getKeys(false)) {
            String name = sec.getString(id + ".name", "?");
            int wins = sec.getInt(id + ".wins", 0);
            if (wins > 0) list.add(Map.entry(name, wins));
        }
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        return list.size() > n ? list.subList(0, n) : list;
    }
}
