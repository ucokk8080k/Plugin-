package com.eventx;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.List;

public class EventListener implements Listener {

    private final EventX plugin;
    private final EventManager mgr;

    public EventListener(EventX plugin) {
        this.plugin = plugin;
        this.mgr = plugin.manager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;

        boolean victimIn = mgr.isInEvent(victim);
        Player attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity d = be.getDamager();
            if (d instanceof Player p) attacker = p;
            else if (d instanceof Projectile pr && pr.getShooter() instanceof Player p) attacker = p;
        }
        boolean attackerIn = attacker != null && mgr.isInEvent(attacker);

        if (!victimIn) {
            if (attackerIn) e.setCancelled(true); // peserta tidak boleh menyerang orang luar
            return;
        }
        if (attacker != null && !attackerIn) { // orang luar tidak boleh menyerang peserta
            e.setCancelled(true);
            return;
        }
        if (!mgr.isAlive(victim) || mgr.getState() != EventManager.State.RUNNING || !mgr.isPvp()) {
            if (e.getCause() == EntityDamageEvent.DamageCause.VOID && mgr.getState() == EventManager.State.RUNNING
                    && mgr.isAlive(victim)) {
                e.setCancelled(true);
                mgr.eliminate(victim, "jatuh ke void");
                return;
            }
            e.setCancelled(true);
            return;
        }
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
            e.setCancelled(true);
            mgr.eliminate(victim, "jatuh ke void");
            return;
        }

        GameType t = mgr.getType();
        switch (t) {
            case LMS -> {
                if (attacker != null && !mgr.isAlive(attacker)) {
                    e.setCancelled(true);
                    return;
                }
                if (e.getFinalDamage() >= victim.getHealth()) {
                    e.setCancelled(true);
                    String reason = attacker != null ? "dibunuh " + attacker.getName() : "mati";
                    mgr.eliminate(victim, reason);
                }
            }
            case SUMO -> {
                if (attacker != null && attacker != victim) e.setDamage(0);
                else e.setCancelled(true);
            }
            case SNOWBALL -> {
                if (e instanceof EntityDamageByEntityEvent be && be.getDamager() instanceof Snowball
                        && attacker != null && attacker != victim) {
                    e.setDamage(0);
                    mgr.snowballHit(victim, attacker);
                } else {
                    e.setCancelled(true);
                }
            }
            default -> e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isInEvent(p)) return;
        e.setKeepInventory(true);
        e.getDrops().clear();
        e.setKeepLevel(true);
        e.setDroppedExp(0);
        e.deathMessage(null);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isDead()) p.spigot().respawn();
            mgr.eliminate(p, "mati");
        });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (!mgr.isInEvent(e.getPlayer())) return;
        Location l = mgr.respawnLocation();
        if (l != null) e.setRespawnLocation(l);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isInEvent(p)) return;
        Block b = e.getBlock();
        if (mgr.getState() == EventManager.State.RUNNING && mgr.getType() == GameType.SPLEEF
                && mgr.isAlive(p) && mgr.spleefBlocks().contains(b.getType())) {
            mgr.recordBlock(b);
            e.setCancelled(false);
            e.setDropItems(false);
            return;
        }
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        if (mgr.isInEvent(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (mgr.isInEvent(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && mgr.isInEvent(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && mgr.isInEvent(p)) {
            e.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!mgr.isInEvent(p) || p.hasPermission("eventx.admin")) return;
        String base = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        int colon = base.indexOf(':');
        if (colon >= 0) base = base.substring(colon + 1);
        List<String> allowed = plugin.getConfig().getStringList("allowed-commands");
        if (!allowed.contains(base)) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("command-blocked"));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        mgr.leave(e.getPlayer(), true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) mgr.restorePending(p);
        }, 5L);
    }
}
