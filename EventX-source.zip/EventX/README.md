# EventX - Plugin Event Minecraft (Paper 1.21.11)

Gamemode: **LMS, Spleef, TNT Run, Sumo, Snowball Fight**

## Cara build jadi .jar (pilih salah satu)

### A. GitHub Actions (paling mudah dari HP)
1. Upload isi folder ini ke repo GitHub (termasuk folder `.github`).
2. Buka tab **Actions** > workflow **Build EventX** > tunggu hijau.
3. Download artifact **EventX** (isinya `EventX.jar`).

### B. Termux
    pkg install openjdk-21 maven
    cd EventX
    mvn package
    # hasil: target/EventX.jar

## Pasang
Taruh `EventX.jar` di folder `plugins/` server Paper 1.21.11, restart server.

## Setup arena (sekali saja, sebagai OP)
    /event setlobby
    /event addspawn <mode>      (berdiri di tiap titik spawn, ulangi sesuai jumlah slot)
    /event setspec <mode>       (opsional, tempat penonton)
    /event setdeathy <mode>     (berdiri di ketinggian batas jatuh; di bawahnya = tereliminasi)
    /event arena <mode>         (cek status)

Tips: Spleef = lantai SNOW_BLOCK; TNT Run = lantai pasir/gravel (bisa banyak lapis);
Sumo = platform kecil di atas void/air; Snowball = arena terbuka dengan penghalang.

## Jalankan event
    /event create <mode>   -> pemain: /event join (atau klik chat)
    /event start           -> paksa mulai
    /event stop            -> hentikan

Inventory/lokasi/HP pemain disimpan lalu dikembalikan otomatis setelah event
(juga setelah server crash, saat pemain login lagi). Blok arena dipulihkan otomatis.

## Permission
- `eventx.join` (default semua pemain)
- `eventx.admin` (default OP)
- `eventx.kit.vip` (kit VIP)

Kit, hadiah (command console), pesan, dan semua angka bisa diubah di `config.yml`.
